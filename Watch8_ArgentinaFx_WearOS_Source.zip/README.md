# Galaxy Watch8 · 汇率通 Wear OS 版

根据用户提供的 `ARSYuanConverter_OneUpload.zip` Android 源码改编。手表版应用 ID `com.exchange.watchfx`，不会覆盖原手机 APK `com.exchange.arsusdcny`。

## 保留的功能

- 7 类美元市场：Blue、Oficial、MEP/Bolsa、CCL、Cripto、Mayorista、Tarjeta；Compra/Venta 双向报价，可切换作为换算市场。
- ARS、USD、CNY、USDT 四种输入货币，按原版规则转换成其他 3 种，带千分位与 2 位小数结果，点击复制。
- DolarAPI 阿根廷各类美元汇率，ExchangeRate API 美元兑人民币参考汇率。
- Binance 公共 P2P USDT/ARS、USDT/CNY；USDC/USDT 现货参考 USD；P2P 不可用时保留原版的现货 / 交叉参考回退，明确显示来源。**不保证 Binance 在所有地区都可访问，也不把 USDT 等同 USD。**
- 最近报价缓存、阿根廷时间、过期提示；手动刷新 60 秒节流；自动启动刷新。不会编造缺失的报价。
- 中文界面、无账户、无 API Key、无定位权限。

## Watch8 界面变化

- 独立 Wear OS App，最低 API 28，Android 35 编译，圆形 40mm / 44mm 屏幕可滚动显示。
- 纯黑 AMOLED 背景，纵向大字卡片和大触摸区域，数字可自动缩小避免裁切。
- 首页换算，独立金额数字键盘、货币切换、七市场报价、Binance 买卖价、信息与时间页面。
- 兼容旋转滚动事件；返回键回到换算首页；不保持屏幕常亮，没有后台持续刷新任务。

## GitHub Actions 编译（**请按下述方式上传**）

方式 A：上传解压后的全部源码（`settings.gradle`、`app/`、`build.gradle`、`tests/` 等）到仓库**根目录**；`.github/workflows/build-apk.yml` 也必须上传。

方式 B：**不解压**上传 `Watch8_ArgentinaFx_WearOS_Source.zip` 到仓库**根目录**，同时**单独上传** `build-apk.yml` 到 `.github/workflows/build-apk.yml`。本 Workflow 支持自动解压 ZIP，不会出现上一工程因根目录缺 `settings.gradle` 的错误。

在 GitHub 仓库 Actions 内运行 `Build Watch8 Exchange Rates APK`，成功后在 Artifacts 下载 `Watch8-Exchange-Rates-APK`，解压得到 `Watch8_ArgentinaFx_WearOS-debug.apk`。将此 APK 传入手表安装（如使用 Wear Installer 2）。

编译配置：Java 17、Gradle 8.10.2、AGP 8.7.3、Android SDK 35。GitHub Ubuntu 24.04 预装 SDK，避免了之前失败的 `android-actions/setup-android@v3` 下载流程。

## 测试边界

原版两组纯 Java 换算测试随项目保留并在 GitHub Actions 中运行。**本文件不是 APK**；实际运行需先在 GitHub Actions 编译。网络访问、Binance 回退是否成功、手表实体显示还需使用 Galaxy Watch8 验证。

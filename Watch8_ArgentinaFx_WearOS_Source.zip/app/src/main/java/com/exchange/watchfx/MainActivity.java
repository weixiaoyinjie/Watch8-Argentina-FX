package com.exchange.watchfx;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.exchange.watchfx.FxCalculator.Currency;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/** Wear OS-first UI over the exact original exchange-rate parsing and calculation classes. */
public final class MainActivity extends Activity {
    private static final int BG = 0xff000000;
    private static final int PANEL = 0xff161b20;
    private static final int PANEL2 = 0xff20282c;
    private static final int OUTLINE = 0xff343c41;
    private static final int FG = 0xfff5f9fa;
    private static final int DIM = 0xffaab9c0;
    private static final int GREEN = 0xff2be3b0;
    private static final int WARN = 0xffffc776;

    private enum Page { HOME, CURRENCY, KEYPAD, MARKETS, USDT, INFO }
    private Page page = Page.HOME;
    private ScrollView scroll;
    private LinearLayout content;

    private final ExecutorService requests = Executors.newSingleThreadExecutor();
    private final ExecutorService p2pRequests = Executors.newFixedThreadPool(2);
    private final Map<String, RateService.Quote> quotes = new LinkedHashMap<>();
    private final Map<Currency, UsdtCalculator.Pair> usdtQuotes = new LinkedHashMap<>();
    private SharedPreferences prefs;
    private Currency from = Currency.ARS;
    private String selectedMarket = "blue";
    private String amount = "1000000";
    private BigDecimal cnyPerUsd;
    private long fetchedDollarAt, fetchedCnyAt, cnySourceTime;
    private boolean loading;
    private String latestError = "";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        prefs = getSharedPreferences("fx_rates_v1", MODE_PRIVATE);
        selectedMarket = prefs.getString("preferred_market", "blue");
        if (!isValidMarket(selectedMarket)) selectedMarket = "blue";
        try { from = Currency.valueOf(prefs.getString("preferred_currency", "ARS")); }
        catch (Exception ignored) { from = Currency.ARS; }
        amount = prefs.getString("preferred_amount", "1000000");
        if (amount.length() > 18) amount = "1000000";
        loadCachedRates();
        showPage(Page.HOME);
        long now = System.currentTimeMillis();
        if (quotes.isEmpty() || cnyPerUsd == null || needsUsdtRefresh(now)
                || now - fetchedDollarAt > 3L * 3600000L || now - fetchedCnyAt > 20L * 3600000L) {
            refreshRates(false);
        }
    }

    private boolean isValidMarket(String candidate) {
        for (String[] row : RateService.MARKETS) if (row[0].equals(candidate)) return true;
        return false;
    }
    private int dp(float n) { return Math.round(getResources().getDisplayMetrics().density * n); }
    private LinearLayout vertical() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout horizontal() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h));
    }
    private GradientDrawable rounded(int color, int border) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(16));
        if (border != 0) d.setStroke(dp(1), border);
        return d;
    }
    private TextView label(String text, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        v.setTextColor(color);
        v.setGravity(Gravity.CENTER);
        v.setIncludeFontPadding(true);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }
    private TextView stretchText(String text, int size, int minSize, int color, boolean bold) {
        TextView v = label(text, size, color, bold);
        v.setMaxLines(1);
        v.setAutoSizeTextTypeUniformWithConfiguration(minSize, size, 1, TypedValue.COMPLEX_UNIT_SP);
        return v;
    }
    private void gap(LinearLayout root, int height) { View v = new View(this); root.addView(v, lp(1, height)); }
    private LinearLayout panel(LinearLayout root) {
        LinearLayout pane = vertical();
        pane.setPadding(dp(10), dp(12), dp(10), dp(12));
        pane.setGravity(Gravity.CENTER_HORIZONTAL);
        pane.setBackground(rounded(PANEL, OUTLINE));
        root.addView(pane, lp(-1, -2));
        return pane;
    }
    private void rowLabel(LinearLayout p, String text) {
        TextView t = label(text, 12, DIM, false); t.setGravity(Gravity.CENTER);
        p.addView(t, lp(-1, -2));
    }
    private void section(LinearLayout root, String title) {
        gap(root, 13);
        TextView t = label(title, 14, FG, true);
        root.addView(t, lp(-1, -2));
        gap(root, 6);
    }
    private TextView button(LinearLayout parent, String title, Runnable action, boolean primary) {
        TextView v = label(title, 14, primary ? BG : FG, true);
        v.setPadding(dp(6), dp(10), dp(6), dp(10));
        v.setMinHeight(dp(44));
        v.setBackground(rounded(primary ? GREEN : PANEL2, primary ? 0 : OUTLINE));
        parent.addView(v, lp(-1, -2));
        v.setOnClickListener(x -> action.run());
        return v;
    }
    private void backButton(LinearLayout parent, String title) {
        TextView b = label("‹  " + title, 17, FG, true);
        b.setMinHeight(dp(45));
        parent.addView(b, lp(-1, -2));
        b.setOnClickListener(v -> showPage(Page.HOME));
        gap(parent, 4);
    }
    private void showPage(Page next) {
        page = next;
        buildContent();
    }
    private void buildContent() {
        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setFocusableInTouchMode(true);
        scroll.setOnGenericMotionListener((view, event) -> {
            if (event.getAction() == MotionEvent.ACTION_SCROLL &&
                    (event.getSource() & InputDevice.SOURCE_ROTARY_ENCODER) == InputDevice.SOURCE_ROTARY_ENCODER) {
                float amount = event.getAxisValue(MotionEvent.AXIS_SCROLL);
                scroll.smoothScrollBy(0, Math.round(-amount * dp(35)));
                return true;
            }
            return false;
        });
        content = vertical();
        // Round-screen safe area on Galaxy Watch8 40/44mm. Content scrolls into the center.
        content.setPadding(dp(23), dp(27), dp(23), dp(36));
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(content);
        setContentView(scroll);
        switch (page) {
            case HOME: home(); break;
            case CURRENCY: currencyPage(); break;
            case KEYPAD: keypadPage(); break;
            case MARKETS: marketsPage(); break;
            case USDT: usdtPage(); break;
            case INFO: infoPage(); break;
        }
    }
    private void home() {
        content.addView(label("汇率通", 20, FG, true));
        content.addView(label("ARS · USD · CNY · USDT", 11, DIM, false));
        gap(content, 8);
        TextView status = label(loading ? "● 正在刷新…" :
            quotes.isEmpty() && cnyPerUsd == null && usdtQuotes.isEmpty() ? "● 暂无数据 · 点击刷新" :
            latestError.isEmpty() && cnyPerUsd != null && usdtQuotes.size() == 3 ? "● 已加载汇率" : "● 部分汇率 / 缓存", 12,
            loading || !latestError.isEmpty() ? WARN : GREEN, true);
        content.addView(status, lp(-1, -2));
        gap(content, 9);
        button(content, loading ? "刷新中…" : "↻ 更新汇率", () -> refreshRates(true), false);
        section(content, "金额换算");
        LinearLayout amountCard = panel(content);
        TextView currencyButton = label("输入币种：" + from.name() + "  ▾", 13, GREEN, true);
        currencyButton.setMinHeight(dp(44));
        amountCard.addView(currencyButton, lp(-1, -2));
        currencyButton.setOnClickListener(v -> showPage(Page.CURRENCY));
        TextView amountButton = stretchText(amount.isEmpty() ? "0" : formatInput(amount), 25, 11, FG, true);
        amountButton.setMinHeight(dp(49));
        amountCard.addView(amountButton, lp(-1, -2));
        amountButton.setOnClickListener(v -> showPage(Page.KEYPAD));
        rowLabel(amountCard, "点击数字输入金额");
        gap(content, 8);
        Currency[] targets = targets();
        for (int i = 0; i < targets.length; i++) {
            Currency target = targets[i];
            LinearLayout p = panel(content);
            rowLabel(p, labelCurrency(target));
            BigDecimal converted = convertFor(target);
            TextView t = stretchText(converted == null ? "—" : format(converted, 2), 24, 10,
                    i == 0 ? GREEN : FG, true);
            t.setMinHeight(dp(32));
            p.addView(t, lp(-1, -2));
            rowLabel(p, converted == null ? "报价未加载" : "点击复制 · " + target.name());
            if (converted != null) {
                final String copy = format(converted, 2) + " " + target.name();
                p.setOnClickListener(v -> copy(copy));
                t.setOnClickListener(v -> copy(copy));
            }
            gap(content, 7);
        }
        section(content, "当前市场：" + marketName(selectedMarket));
        RateService.Quote q = quotes.get(selectedMarket);
        LinearLayout rateCard = panel(content);
        rowLabel(rateCard, "1 USD / ARS");
        rateCard.addView(stretchText("买 " + (q == null ? "—" : format(q.compra, 2)) + "  ·  卖 " +
                (q == null ? "—" : format(q.venta, 2)), 15, 10, FG, true), lp(-1, -2));
        rateCard.setOnClickListener(v -> showPage(Page.MARKETS));
        gap(content, 9);
        button(content, "7 种美元市场  ›", () -> showPage(Page.MARKETS), false);
        gap(content, 7);
        button(content, "Binance USDT  ›", () -> showPage(Page.USDT), false);
        gap(content, 7);
        button(content, "USD/CNY · 时间 · 来源  ›", () -> showPage(Page.INFO), false);
    }
    private Currency[] targets() {
        if (from == Currency.ARS) return new Currency[]{Currency.USD, Currency.CNY, Currency.USDT};
        if (from == Currency.USD) return new Currency[]{Currency.ARS, Currency.CNY, Currency.USDT};
        if (from == Currency.CNY) return new Currency[]{Currency.ARS, Currency.USD, Currency.USDT};
        return new Currency[]{Currency.ARS, Currency.USD, Currency.CNY};
    }
    private String formatInput(String raw) {
        if (raw.endsWith(".")) {
            try { return format(new BigDecimal(raw.substring(0, raw.length() - 1)), 0) + "."; }
            catch (Exception ignored) { return raw; }
        }
        try { return format(new BigDecimal(raw), raw.contains(".") ?
                Math.min(6, raw.length() - raw.indexOf('.') - 1) : 0); }
        catch (Exception ignored) { return raw; }
    }
    private BigDecimal convertFor(Currency to) {
        BigDecimal value;
        try { value = new BigDecimal(amount); if (value.signum() < 0) return null; }
        catch (Exception ignored) { return null; }
        try {
            if (from == Currency.USDT || to == Currency.USDT) {
                Currency fiat = from == Currency.USDT ? to : from;
                UsdtCalculator.Pair p = usdtQuotes.get(fiat);
                return p == null ? null : UsdtCalculator.convert(value, from, to, p);
            }
            RateService.Quote q = quotes.get(selectedMarket);
            if (q == null && (from == Currency.ARS || to == Currency.ARS)) return null;
            if (cnyPerUsd == null && (from == Currency.CNY || to == Currency.CNY)) return null;
            return FxCalculator.convert(value, from, to,
                    q == null ? BigDecimal.ONE : q.compra,
                    q == null ? BigDecimal.ONE : q.venta,
                    cnyPerUsd == null ? BigDecimal.ONE : cnyPerUsd);
        } catch (Exception ignored) { return null; }
    }
    private String labelCurrency(Currency c) {
        switch (c) {
            case ARS: return "阿根廷比索 ARS";
            case USD: return "美元 USD";
            case CNY: return "人民币 CNY";
            default: return "泰达币 USDT";
        }
    }
    private void currencyPage() {
        backButton(content, "选择币种");
        for (Currency c : Currency.values()) {
            button(content, (c == from ? "✓ " : "") + labelCurrency(c), () -> {
                from = c;
                prefs.edit().putString("preferred_currency", c.name()).apply();
                showPage(Page.HOME);
            }, c == from);
            gap(content, 9);
        }
    }
    private void keypadPage() {
        backButton(content, "输入金额");
        LinearLayout p = panel(content);
        TextView value = stretchText(amount.isEmpty() ? "0" : formatInput(amount), 27, 10, GREEN, true);
        value.setMinHeight(dp(44));
        p.addView(value, lp(-1, -2));
        gap(content, 14);
        String[][] keys = {{"7", "8", "9"}, {"4", "5", "6"}, {"1", "2", "3"}, {".", "0", "⌫"}};
        for (String[] nums : keys) {
            LinearLayout row = horizontal();
            content.addView(row, lp(-1, -2));
            for (String num : nums) {
                TextView key = label(num, 20, FG, true);
                LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(0, dp(46), 1);
                param.setMargins(dp(2), dp(2), dp(2), dp(2));
                row.addView(key, param);
                key.setBackground(rounded(PANEL2, OUTLINE));
                key.setOnClickListener(v -> {
                    applyKey(num);
                    value.setText(amount.isEmpty() ? "0" : formatInput(amount));
                });
            }
        }
        gap(content, 10);
        button(content, "清零 AC", () -> { amount = ""; value.setText("0"); persistAmount(); }, false);
        gap(content, 7);
        button(content, "✓ 完成", () -> showPage(Page.HOME), true);
    }
    private void applyKey(String key) {
        if ("⌫".equals(key)) {
            if (!amount.isEmpty()) amount = amount.substring(0, amount.length() - 1);
        } else if (".".equals(key)) {
            if (!amount.contains(".")) amount = amount.isEmpty() ? "0." : amount + ".";
        } else if (amount.length() < 16) {
            if ("0".equals(amount) && !".".equals(key)) amount = key;
            else amount += key;
        }
        persistAmount();
    }
    private void persistAmount() { prefs.edit().putString("preferred_amount", amount).apply(); }
    private void marketsPage() {
        backButton(content, "美元市场");
        rowLabel(content, "Compra / Venta 每 1 USD 的比索报价");
        gap(content, 9);
        for (String[] market : RateService.MARKETS) {
            String id = market[0];
            RateService.Quote q = quotes.get(id);
            LinearLayout p = panel(content);
            p.addView(label((id.equals(selectedMarket) ? "✓  " : "") + market[1], 16,
                    id.equals(selectedMarket) ? GREEN : FG, true));
            gap(p, 4);
            rowLabel(p, market[2]);
            gap(p, 4);
            p.addView(stretchText("买: " + (q == null ? "—" : format(q.compra, 2)), 16, 11, FG, true));
            p.addView(stretchText("卖: " + (q == null ? "—" : format(q.venta, 2)), 16, 11, GREEN, true));
            p.setMinimumHeight(dp(92));
            p.setOnClickListener(v -> {
                selectedMarket = id;
                prefs.edit().putString("preferred_market", id).apply();
                showPage(Page.HOME);
            });
            gap(content, 9);
        }
    }
    private void usdtPage() {
        backButton(content, "USDT 报价");
        rowLabel(content, "Binance P2P / 公开现货交叉参考");
        gap(content, 10);
        for (Currency fiat : new Currency[]{Currency.ARS, Currency.USD, Currency.CNY}) {
            UsdtCalculator.Pair q = usdtQuotes.get(fiat);
            LinearLayout p = panel(content);
            p.addView(label("1 USDT / " + fiat.name(), 17, GREEN, true));
            gap(p, 6);
            rowLabel(p, "买入 USDT · 付出法币");
            p.addView(stretchText(q == null ? "—" : format(q.buyUsdt, fiat == Currency.ARS ? 2 : 4),
                    21, 10, FG, true), lp(-1, -2));
            rowLabel(p, "卖出 USDT · 得到法币");
            p.addView(stretchText(q == null ? "—" : format(q.sellUsdt, fiat == Currency.ARS ? 2 : 4),
                    21, 10, GREEN, true), lp(-1, -2));
            gap(p, 4);
            rowLabel(p, q == null ? "报价不可用" : q.source);
            rowLabel(p, q == null ? "" : argentinaDate(q.fetchedAt) + " 阿根廷时间");
            if (q != null && System.currentTimeMillis() - q.fetchedAt > 15L * 60000) {
                p.addView(label("⚠ 报价已超过 15 分钟", 11, WARN, true));
            }
            gap(content, 9);
        }
        TextView desc = label("法币 → USDT 用买入价；USDT → 法币用卖出价。USD 以 USDC/USDT 现货近似；USDC 不等于法定美元。交叉参考不等于 P2P 实价。", 12, DIM, false);
        content.addView(desc, lp(-1, -2));
    }
    private void infoPage() {
        backButton(content, "数据详情");
        section(content, "USD / CNY 参考汇率");
        LinearLayout p = panel(content);
        p.addView(label(cnyPerUsd == null ? "暂无 USD/CNY" : "1 USD = " + format(cnyPerUsd, 4) + " CNY", 15, GREEN, true));
        rowLabel(p, "人民币以美元中间参考汇率交叉计算");
        section(content, "数据更新时间（阿根廷）");
        LinearLayout t = panel(content);
        RateService.Quote chosen = quotes.get(selectedMarket);
        rowLabel(t, "美元市场：" + (chosen == null ? "暂无" : argentinaDate(parseInstant(chosen.updated))));
        gap(t, 4);
        rowLabel(t, "USD/CNY：" + (cnyPerUsd == null ? "暂无" : argentinaDate(cnySourceTime)));
        if (fetchedDollarAt > 0 && System.currentTimeMillis() - fetchedDollarAt > 6L * 3600000)
            t.addView(label("⚠ 美元缓存较旧", 11, WARN, false));
        if (fetchedCnyAt > 0 && System.currentTimeMillis() - fetchedCnyAt > 36L * 3600000)
            t.addView(label("⚠ 人民币缓存较旧", 11, WARN, false));
        if (!latestError.isEmpty()) {
            section(content, "加载提示");
            content.addView(label(latestError, 11, WARN, false));
        }
        section(content, "报价来源");
        button(content, "DolarAPI", () -> open("https://dolarapi.com"), false);
        gap(content, 7);
        button(content, "ExchangeRate API", () -> open("https://www.exchangerate-api.com"), false);
        gap(content, 7);
        button(content, "Binance", () -> open("https://www.binance.com"), false);
        section(content, "重要说明");
        content.addView(label("Compra/Venta 是报价方买入/卖出美元的价格。Blue 是非官方市场；Tarjeta 不是现金兑换价。换算仅供参考，不包含手续费。离线显示上次缓存，不伪造实时行情。", 12, DIM, false));
    }
    private String marketName(String id) {
        for (String[] v : RateService.MARKETS) if (v[0].equals(id)) return v[1];
        return id;
    }
    private void open(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { Toast.makeText(this, "手表上没有浏览器", Toast.LENGTH_SHORT).show(); }
    }
    private void copy(String s) {
        ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cb != null) cb.setPrimaryClip(ClipData.newPlainText("汇率换算", s));
        Toast.makeText(this, "已复制 " + s, Toast.LENGTH_SHORT).show();
    }
    private String format(BigDecimal n, int digits) {
        NumberFormat f = NumberFormat.getNumberInstance(Locale.US);
        f.setGroupingUsed(true);
        f.setRoundingMode(RoundingMode.HALF_UP);
        f.setMinimumFractionDigits(digits);
        f.setMaximumFractionDigits(digits);
        return f.format(n);
    }
    private long parseInstant(String s) {
        try { return Instant.parse(s).toEpochMilli(); }
        catch (Exception ignored) { return 0L; }
    }
    private String argentinaDate(long when) {
        if (when <= 0L) return "未知";
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("America/Argentina/Buenos_Aires"));
        return f.format(new Date(when));
    }
    private void loadCachedRates() {
        try {
            String raw = prefs.getString("cached_dolar", "");
            if (!raw.isEmpty()) quotes.putAll(RateService.parseDollars(raw));
            fetchedDollarAt = prefs.getLong("cached_dolar_at", 0);
        } catch (Exception ignored) { quotes.clear(); }
        try {
            String raw = prefs.getString("cached_cny", "");
            if (!raw.isEmpty()) {
                RateService.YuanRate rate = RateService.parseCny(raw);
                cnyPerUsd = rate.cnyPerUsd;
                cnySourceTime = rate.sourceTimestampMs;
            }
            fetchedCnyAt = prefs.getLong("cached_cny_at", 0);
        } catch (Exception ignored) { cnyPerUsd = null; }
        for (Currency c : new Currency[]{Currency.ARS, Currency.USD, Currency.CNY}) {
            try {
                String raw = prefs.getString("cached_usdt_" + c.name(), "");
                if (!raw.isEmpty()) usdtQuotes.put(c, BinanceRateService.pairFromCache(raw));
            } catch (Exception ignored) { usdtQuotes.remove(c); }
        }
    }
    private boolean needsUsdtRefresh(long now) {
        for (Currency c : new Currency[]{Currency.ARS, Currency.USD, Currency.CNY}) {
            UsdtCalculator.Pair q = usdtQuotes.get(c);
            if (q == null || now - q.fetchedAt > 3L * 60000) return true;
        }
        return false;
    }
    private void refreshRates(boolean manual) {
        if (loading) return;
        long now = System.currentTimeMillis();
        if (manual && now - prefs.getLong("last_manual_refresh", 0) < 60000) {
            Toast.makeText(this, "一分钟内请勿重复刷新", Toast.LENGTH_SHORT).show();
            return;
        }
        if (manual) prefs.edit().putLong("last_manual_refresh", now).apply();
        loading = true;
        latestError = "";
        if (page == Page.HOME) buildContent();
        final boolean needDollar = manual || quotes.isEmpty() || now - fetchedDollarAt >= 3L * 3600000;
        final boolean needCny = cnyPerUsd == null || now - fetchedCnyAt >= 20L * 3600000;
        final boolean needBinance = manual || needsUsdtRefresh(now);
        requests.execute(() -> {
            String dollarRaw = null, yuanRaw = null;
            Map<String, RateService.Quote> newDollar = null;
            RateService.YuanRate yuan = null;
            StringBuilder errors = new StringBuilder();
            if (needDollar) {
                try {
                    dollarRaw = RateService.fetch(RateService.DOLAR_ENDPOINT);
                    newDollar = RateService.parseDollars(dollarRaw);
                } catch (Exception e) { errors.append("DolarAPI 失败（").append(e.getMessage()).append("）"); }
            }
            if (needCny) {
                try {
                    yuanRaw = RateService.fetch(RateService.CNY_ENDPOINT);
                    yuan = RateService.parseCny(yuanRaw);
                } catch (Exception e) {
                    if (errors.length() > 0) errors.append("；");
                    errors.append("USD/CNY 失败（").append(e.getMessage()).append("）");
                }
            }
            Map<Currency, UsdtCalculator.Pair> newUsdt = new LinkedHashMap<>();
            if (needBinance) {
                long at = System.currentTimeMillis();
                BinanceRateService.Book usdBook = null;
                try {
                    usdBook = BinanceRateService.parseSpotBook(
                            RateService.fetch(BinanceRateService.SPOT_BASE + "USDCUSDT"), "USDCUSDT");
                    newUsdt.put(Currency.USD, BinanceRateService.usdFromUsdcBook(usdBook, at));
                } catch (Exception ignored) { /* never fabricate missing data */ }
                Future<UsdtCalculator.Pair> arsFuture = p2pRequests.submit(() -> BinanceRateService.fetchP2pPair("ARS", at));
                Future<UsdtCalculator.Pair> cnyFuture = p2pRequests.submit(() -> BinanceRateService.fetchP2pPair("CNY", at));
                try { newUsdt.put(Currency.ARS, arsFuture.get(25, TimeUnit.SECONDS)); }
                catch (Exception ignored) { arsFuture.cancel(true); }
                try { newUsdt.put(Currency.CNY, cnyFuture.get(25, TimeUnit.SECONDS)); }
                catch (Exception ignored) { cnyFuture.cancel(true); }
                if (!newUsdt.containsKey(Currency.ARS) && usdBook != null) {
                    try {
                        BinanceRateService.Book arsBook = BinanceRateService.parseSpotBook(
                                RateService.fetch(BinanceRateService.SPOT_BASE + "USDCARS"), "USDCARS");
                        newUsdt.put(Currency.ARS, BinanceRateService.arsFromBooks(usdBook, arsBook, at));
                    } catch (Exception ignored) { }
                }
                if (!newUsdt.containsKey(Currency.CNY) && newUsdt.containsKey(Currency.USD)) {
                    BigDecimal rate = yuan != null ? yuan.cnyPerUsd : cnyPerUsd;
                    if (rate != null) try {
                        newUsdt.put(Currency.CNY, BinanceRateService.cnyFromUsdPair(newUsdt.get(Currency.USD), rate, at));
                    } catch (Exception ignored) { }
                }
                for (Currency fiat : new Currency[]{Currency.ARS, Currency.USD, Currency.CNY}) {
                    if (!newUsdt.containsKey(fiat) && !usdtQuotes.containsKey(fiat)) {
                        if (errors.length() > 0) errors.append("；");
                        errors.append("Binance ").append(fiat.name()).append("/USDT 暂无报价");
                    }
                }
            }
            final String rawDollar = dollarRaw;
            final String rawCny = yuanRaw;
            final Map<String, RateService.Quote> finalDollar = newDollar;
            final RateService.YuanRate finalYuan = yuan;
            final String finalErrors = errors.toString();
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                long finished = System.currentTimeMillis();
                SharedPreferences.Editor editor = prefs.edit();
                if (finalDollar != null) {
                    quotes.clear(); quotes.putAll(finalDollar);
                    fetchedDollarAt = finished;
                    editor.putString("cached_dolar", rawDollar).putLong("cached_dolar_at", finished);
                }
                if (finalYuan != null) {
                    cnyPerUsd = finalYuan.cnyPerUsd;
                    cnySourceTime = finalYuan.sourceTimestampMs;
                    fetchedCnyAt = finished;
                    editor.putString("cached_cny", rawCny).putLong("cached_cny_at", finished);
                }
                for (Map.Entry<Currency, UsdtCalculator.Pair> entry : newUsdt.entrySet()) {
                    usdtQuotes.put(entry.getKey(), entry.getValue());
                    try { editor.putString("cached_usdt_" + entry.getKey().name(),
                            BinanceRateService.pairToCache(entry.getValue())); }
                    catch (Exception ignored) { }
                }
                editor.apply();
                latestError = finalErrors;
                loading = false;
                buildContent();
                if (manual) Toast.makeText(this, finalErrors.isEmpty() ? "更新完成" : "部分更新失败，保留缓存", Toast.LENGTH_SHORT).show();
            });
        });
    }
    @Override public void onBackPressed() {
        if (page != Page.HOME) showPage(Page.HOME);
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        requests.shutdownNow();
        p2pRequests.shutdownNow();
        super.onDestroy();
    }
}
